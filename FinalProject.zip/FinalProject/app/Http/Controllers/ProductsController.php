<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductsController extends Controller
{
    public function index(){
    	$products= Product::all();
    	return view('index', array(
		'products'=>$products
		));
    }
    public function getProductDetail($MaHoa){

        $product = Product::find($MaHoa);

        if($product){

            return view('details',array(

                'product' => $product

            ));

        }else{

            return redirect()->back();

        }

}
}
