@extends('master')
@section('content')
<div id="content">
			<div class="row">
				<div class="col-sm-9">

					<div class="row">
						<div class="col-sm-2">
							<img src="{{asset('images/hoa/' . $product->Hinh)}}" alt="">
						</div>
						<div class="col-sm-12">
							<div class="single-item-body">
								<p class="single-item-title">{{$product->TenHoa}}</p>
								<p class="single-item-price">
									<span>{{$product->Gia}}</span>
								</p>
							</div>

							<div class="clearfix"></div>
							<div class="space20">&nbsp;</div>

							<div class="single-item-desc">
								<p>{{$product->NoiDung}}</p>
							</div>
							

							<p>Options:</p>
							<div class="single-item-options">
								
								
																<a class="add-to-cart" href="#"><i class="fa fa-shopping-cart"></i></a>
								<div class="clearfix"></div>
							</div>
						</div>
				

					
					 <!-- .beta-products-list -->
				</div>
				
			
		</div>
		</div>
		</div> <!-- #content -->
@endsection